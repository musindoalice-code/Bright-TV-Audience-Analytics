/*
=========================================================
Bright TV Audience Analytics
File: 05_Final_Dataset.sql
Author: Alice Musindo
Date: July 2026
Description:
Join the cleaned, feature-engineered subscriber and viewership data into a
single analysis-ready table. This MUST run before 06_Exploratory_Data_Analysis.sql,
07_KPI_Analysis.sql, and 08_Business_Insights.sql, since all three query the
FinalDataset table this script creates.

FIX NOTE: in the original draft, this logic ended in a bare SELECT with no
CREATE TABLE/VIEW around it, so FinalDataset was never actually persisted —
any script querying "FROM FinalDataset" would have failed with a table-not-found
error. This version fixes that by materialising the result as a table.
Tools:
- Databricks SQL
=========================================================
*/

CREATE OR REPLACE TABLE workspace.default.FinalDataset AS
SELECT
    COALESCE(v.userid, u.UserID) AS sub_id,
    v.month_id,
    v.watch_date,
    v.day_of_week,
    v.day_name,
    v.day_classification,
    v.month_name,
    v.Tv_channel,
    v.time_of_day,
    v.hour_of_day,
    v.screen_time_bucket,
    v.duration,
    u.Region,
    u.age_groups,
    u.is_incomplete_profile,
    u.email_flag,
    u.sm_flag,
    u.Race,
    u.Gender
FROM workspace.default.viewership_features AS v
LEFT JOIN workspace.default.user_profiles_features AS u
    ON v.userid = u.UserID;


-- ---------------------------------------------------------------
-- VALIDATION
-- ---------------------------------------------------------------

-- Row count should match the deduplicated viewership_clean count
SELECT COUNT(*) AS final_dataset_rows FROM workspace.default.FinalDataset;

-- Confirm every row resolved to a subscriber (should be 0)
SELECT COUNT(*) AS unmatched_rows
FROM workspace.default.FinalDataset
WHERE sub_id IS NULL;
