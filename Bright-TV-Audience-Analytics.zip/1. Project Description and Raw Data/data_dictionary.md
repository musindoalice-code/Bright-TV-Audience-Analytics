# Data Dictionary

## Raw source tables (Databricks: `workspace.default`)

The pipeline in `3. Data Processing/` starts from two raw Databricks tables. Only
the columns actually referenced by the SQL pipeline are documented below — the raw
tables may contain additional columns not used in this project.

### 1. `bright_tv_userprofiles`

| Column | Description | Data Quality Note |
|---|---|---|
| `UserID` | Unique subscriber identifier | No duplicates found |
| `Province` | Subscriber's province of residence, as entered at sign-up | Contains blank (`' '`) and literal `'None'` text values instead of true nulls; standardised to `'Uncategorized'` in `03_Data_Cleaning.sql` |
| `age` | Subscriber age in years | 920 subscribers recorded at `age = 0` — treated as incomplete sign-up records, not a real "Infants" segment (see `is_incomplete_profile` flag) |
| `email` | Subscriber's email address | Used to derive `email_flag`; blank/`'None'`/null all mean "no email on file" |
| `Social Media Handle` | Subscriber's social handle | Used to derive `sm_flag`; same blank/`'None'`/null handling as email |
| `Race` | Subscriber race classification | Contains a literal `'other'` value and blanks, both standardised to `'None'`; true nulls are left as null (kept distinct from an explicit "other" response) |
| `gender` | Subscriber gender | Contains blank (`' '`) values, standardised to `'None'` |

### 2. `bright_tv_viewership`

| Column | Description | Data Quality Note |
|---|---|---|
| `UserID0` | Subscriber ID (one of two ID columns present in this table) | Populated for some rows |
| `userid4` | Subscriber ID (second ID column) | Populated for the remaining rows — `COALESCE(UserID0, userid4)` is used throughout the pipeline to resolve a single subscriber ID. **Why the raw table has two separate ID columns for the same value is not yet known — worth following up on the source system if this project is extended.** |
| `RecordDate2` | Timestamp of the viewing session | Used to derive `watch_date`, `day_of_week`, `day_name`, `month_id`, `month_name`, `hour_of_day`, and `time_of_day` |
| `Channel2` | Channel watched | Contains inconsistent naming for the same channel (e.g. `SawSee`/`Sawsee`, four different labels for the same "Live Events" channel) — standardised in `03_Data_Cleaning.sql` |
| `Duration 2` | Session length | Stored as a time value; converted to the `duration` text field and bucketed into `screen_time_bucket` |

## Derived / analysis-ready fields (built by the pipeline)

These fields don't exist in the raw tables — they're created across
`03_Data_Cleaning.sql` and `04_Feature_Engineering.sql`, and land in the final
`FinalDataset` table built by `05_Final_Dataset.sql`:

| Field | Built in | Description |
|---|---|---|
| `Region` | 03 | Cleaned `Province`, with `'Uncategorized'` replacing blanks/nulls |
| `email_flag` / `sm_flag` | 03 | 1 if a real email/social handle is on file, 0 otherwise |
| `age_groups` | 04 | Infants / Kids / Teenager / Youth / Adult / Elder / Pensioner, binned from `age` |
| `is_incomplete_profile` | 04 | 1 if `age = 0` (flags likely-incomplete sign-ups rather than reporting them as a real age segment) |
| `Tv_channel` | 03 | Standardised channel name |
| `month_id`, `watch_date`, `day_of_week`, `day_name`, `month_name` | 04 | Calendar breakdown of `RecordDate2` |
| `day_classification` | 04 | `weekend` if Saturday/Sunday, else `weekday` |
| `time_of_day` | 04 | Midnight / Morning / Afternoon / Evening daypart, binned from the session's hour |
| `hour_of_day` | 04 | Hour (0–23) extracted from `RecordDate2` |
| `duration` | 04 | Session length as `HH:mm:ss` text |
| `screen_time_bucket` | 04 | No Usage / Low / Medium / High usage, binned from `duration` |

## `FinalDataset` (built by `05_Final_Dataset.sql`)

The single analysis-ready table all EDA, KPI, and business-insight queries run
against — one row per viewing session, joined to that session's subscriber
demographics. See `05_Final_Dataset.sql` for the exact join and column list.

## Reference export

`raw_subscriber_demographics.csv` and `raw_viewing_behaviour.csv` in this folder are
a sample export of the pipeline's output (equivalent to querying
`user_profiles_features` and `FinalDataset`) — useful for offline analysis in Excel,
but the SQL pipeline in `3. Data Processing/` is the source of truth and should be
run against the live Databricks tables for anything client-facing.
