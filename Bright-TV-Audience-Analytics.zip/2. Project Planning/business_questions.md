# Business Questions

Bright TV is facing high subscriber churn risk and low engagement on specific
broadcasting slots, with no centralised visibility into how subscriber demographics
relate to viewing behaviour. This project answers the following questions to close
that gap. Each question is mapped to the SQL script and section that answers it.

## Audience Analysis (`06_Exploratory_Data_Analysis.sql`)
| # | Question | Answered in |
|---|---|---|
| A1 | How many subscribers does Bright TV have? | `07_KPI_Analysis.sql` |
| A2 | Which province has the highest number of subscribers? | `06_Exploratory_Data_Analysis.sql` |
| A3 | Which age group watches the most television? | `06_Exploratory_Data_Analysis.sql` |
| A4 | What is the gender distribution of subscribers? | `06_Exploratory_Data_Analysis.sql` |
| A5 | Which race groups are represented? | `06_Exploratory_Data_Analysis.sql` |

## Viewing Behaviour (`07_KPI_Analysis.sql`)
| # | Question | Answered in |
|---|---|---|
| B1 | Which channels are watched most frequently? | `07_KPI_Analysis.sql` |
| B2 | What time of day has the highest audience? | `07_KPI_Analysis.sql` |
| B3 | Which days generate the highest viewing activity? | `06_Exploratory_Data_Analysis.sql` |
| B4 | What percentage of viewing occurs during weekends? | `07_KPI_Analysis.sql` |
| B5 | Which viewers are classified as heavy users? | `07_KPI_Analysis.sql` |

## Business Intelligence (`08_Business_Insights.sql`)
| # | Question | Answered in |
|---|---|---|
| C1 | Which audience segment should Bright TV target? | `08_Business_Insights.sql` |
| C2 | Which provinces require increased marketing investment? | `08_Business_Insights.sql` |
| C3 | Which channels deserve further investment, by daypart? | `08_Business_Insights.sql` |

## Data quality questions raised during planning
These weren't in the original brief but emerged once the raw data was profiled, and
they materially affect how the questions above should be answered:
- Is `Region = Uncategorized` a real province, or a placeholder for unknown? →
  Treated as unknown; excluded from "top province" rankings.
- Are the 920 subscribers recorded at `age = 0` real infant subscribers? →
  No — flagged as incomplete sign-up profiles (`is_incomplete_profile`) and excluded
  from age-based demographic analysis rather than reported as a genuine segment.
- Are `email_flag` / `sm_flag` useful for segmentation in this extract? → No, both
  are constant (=1) across every row in the data provided, so they carry no
  discriminating information here.
