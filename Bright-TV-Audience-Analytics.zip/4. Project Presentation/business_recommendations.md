# Business Recommendations

Based on the findings in `executive_summary.md`:

1. **Prioritise the 3–6pm slot for premium ad inventory.** 3pm (15:00) is the single
   busiest hour by total minutes watched, and the Afternoon daypart leads both
   session count and watch-time. Concentrate high-value advertising and premium
   content premieres here rather than spreading spend evenly across the day.

2. **Re-evaluate programming investment using watch-time, not session count.**
   The ICC Cricket World Cup 2011 content generates more total viewing minutes than
   Live Events despite fewer sessions — a sign that long-form sports content drives
   deeper engagement per session. Content and licensing decisions should weight
   total watch-time alongside reach.

3. **Launch a re-engagement campaign for the ~23% of subscribers with zero
   recorded viewing.** This "Inactive" segment is the second-largest engagement
   tier after "Light" viewers and represents the clearest near-term churn risk —
   they are paying subscribers generating no viewing activity at all.

4. **Fix profile completion at sign-up before running demographic-targeted
   campaigns.** With gender unrecorded for 17% of subscribers and race unrecorded
   for 25%, any campaign segmented by these fields is working with an incomplete
   picture. A short mandatory profile step at sign-up (or a targeted follow-up
   prompt to existing incomplete profiles) would materially improve targeting
   accuracy going forward.

5. **Increase marketing push in provinces with large subscriber bases but weak
   engagement**, using the region-level inactivity rates from
   `04_eda_and_kpis.sql` (Section C2) to identify which specific provinces to
   prioritise — rather than only marketing where subscriber counts are already
   highest.

6. **Treat the "Uncategorized" region and the age = 0 "Infants" segment as data
   quality gaps to close, not real audience segments to design content for.**
   Both point to the same underlying issue — incomplete sign-up capture for a
   subset of subscribers — and should be a data-collection fix rather than a
   targeting strategy.

## Suggested next steps (not yet built)

- Wire `subscriber_engagement_summary` into Power BI as the primary table behind
  the executive dashboard (see `4. Project Presentation/` for the dashboard file
  once built).
- Extend the analysis beyond Q1 2016 once more months of viewing data are
  available, to confirm the weekday/weekend and peak-hour patterns hold
  year-round rather than being specific to this quarter.
