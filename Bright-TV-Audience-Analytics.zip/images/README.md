# images/

Add these here when ready (both are optional — the main README doesn't currently
hard-link to them, so nothing breaks if they're missing):

- `banner.png` — a project banner for the top of the main README
- `dashboard.png` — a screenshot of the Power BI dashboard once it's built

Git does not track empty folders, so this file exists only to keep `images/` present
in the repository until real images are added.
